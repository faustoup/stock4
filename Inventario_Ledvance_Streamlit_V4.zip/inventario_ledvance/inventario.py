"""Inventario de la cuenta: usa únicamente el campo visible elegido por el usuario."""
import io
import re
import time
from collections import defaultdict
from pathlib import Path
from urllib.parse import urlparse, quote
BASE = "https://tienda.ledvance.mx"
LISTA = Path(__file__).with_name("sku_vigentes.txt")

def cantidad(texto):
    m=re.fullmatch(r"\s*(\d{1,3}(?:,\d{3})+|\d+)\s+(?:pieza\(s\)|piezas?|artículos?)\s+queda(?:n)?\s*",texto,re.I)
    if not m:raise ValueError("No hay un mensaje inequívoco de piezas restantes.")
    return int(m[1].replace(",",""))

def excel(filas):
    import xlsxwriter
    out=io.BytesIO()
    with xlsxwriter.Workbook(out,{'in_memory':True,'strings_to_formulas':False,'strings_to_urls':False}) as wb:
        sh=wb.add_worksheet('Inventario');head=wb.add_format({'bold':True,'font_color':'white','bg_color':'#153C54'})
        sh.write_row(0,0,['SKU','Cantidad'],head);sh.set_column('A:B',18);sh.freeze_panes(1,0)
        for i,(s,q) in enumerate(filas,1):
            sh.write_string(i,0,s)
            if q is not None:sh.write_number(i,1,q)
        sh.autofilter(0,0,len(filas),1)
    return out.getvalue()

def cuenta_activa(page, timeout):
    # Verificar una página de cuenta con acción de cierre de sesión; nunca inspeccionar contraseñas.
    page.goto(BASE+'/account',wait_until='domcontentloaded',timeout=60000)
    limite=time.monotonic()+timeout
    while time.monotonic()<limite:
        u=urlparse(page.url)
        if u.scheme=='https' and (u.hostname==urlparse(BASE).hostname or (u.hostname or '').endswith(('.ledvance.mx','.shopify.com')) or u.hostname=='shopify.com'):
            if page.locator('a[href*="logout"], a[href*="sign_out"], form[action*="logout"]').count() or page.get_by_text(re.compile(r'^(cerrar sesión|log out|sign out)$',re.I)).count():
                return
        time.sleep(.6)
    raise RuntimeError("No se pudo confirmar una sesión iniciada en la página de cuenta. No se generó inventario.")

def indice(context):
    # El catálogo solo mapea SKU a variante. Aquí no se leen cantidades.
    idx=defaultdict(set); vistos=set()
    for pag in range(1,101):
        r=context.request.get(BASE+f'/products.json?limit=250&page={pag}',timeout=30000)
        if not r.ok:raise RuntimeError(f'Catálogo no disponible ({r.status}).')
        items=r.json()['products']
        if not items:break
        nuevos={p['id'] for p in items}-vistos
        if not nuevos:raise RuntimeError("El catálogo repitió una página.")
        vistos.update(nuevos)
        for p in items:
            for v in p['variants']:
                if v.get('sku'):idx[str(v['sku']).strip()].add((p['handle'],str(v['id'])))
        if len(items)<250:break
    else:raise RuntimeError("No se llegó al final del catálogo.")
    return idx

# Captura solo lo que está visible en la ficha principal y dentro del formulario correcto.
CAPTURA = r"""({h}) => {
 const visible=e=>!!e&&!!e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden';
 const norm=t=>(t||'').trim().replace(/\s+/g,' ');
 const forms=[...document.querySelectorAll('[data-product-form][data-product]')].filter(f=>{
    try{return visible(f)&&JSON.parse(f.dataset.product).handle===h}catch{return false}});
 if(forms.length!==1) return null;
 const f=forms[0], box=f.closest('.product__information');
 if(!box)return null;
 const selected=f.querySelector('[name="id"]');
 if(!selected)return null;
 const v=JSON.parse(f.dataset.product).variants.filter(v=>String(v.id)===String(selected.value));
 if(v.length!==1)return null;
 const heads=[...box.querySelectorAll('.sku')].filter(visible).map(e=>norm(e.innerText));
 const opt=selected.selectedOptions?.[0];
 return {variant:String(v[0].id), sku:norm(v[0].sku), optionSku:opt?.dataset.sku||'',
   title:norm(v[0].title), headings:heads,
   stocks:[...f.querySelectorAll('.variants-meta .var-item[data-meta]')].filter(visible)
      .flatMap(row=>[...row.querySelectorAll('.meta-thresold')].filter(visible)
      .map(el=>({label:norm(row.dataset.meta), text:norm(el.innerText)})))};
}"""

def lectura(estado, sku, vid):
    if not estado or (estado['variant'],estado['sku'])!=(vid,sku):
        raise ValueError("No se confirmó la variante seleccionada.")
    if estado['optionSku'] not in ('',sku) or estado['headings'] != [sku]:
        raise ValueError("El SKU visible no coincide con el SKU solicitado.")
    if len(estado['stocks'])!=1 or estado['stocks'][0]['label']!=estado['title']:
        raise ValueError("No hay una única existencia visible para el material seleccionado.")
    return cantidad(estado['stocks'][0]['text'])

def leer_ficha(page,sku,pares):
    if len(pares)!=1:raise ValueError("SKU ausente o repetido en el catálogo.")
    h,vid=next(iter(pares))
    resp=page.goto(BASE+'/products/'+quote(h,safe='')+'?variant='+vid,wait_until='domcontentloaded',timeout=30000)
    if not resp or resp.status in (401,403,429):raise RuntimeError("La tienda no autorizó la consulta o limitó su frecuencia.")
    if not resp.ok:raise ValueError(f"Ficha no disponible ({resp.status})")
    parsed=urlparse(page.url)
    if parsed.hostname!=urlparse(BASE).hostname or parsed.path.rstrip('/')!='/products/'+h:
        raise RuntimeError("La consulta salió de la ficha del producto.")
    limite=time.monotonic()+6;prev=None;motivo="Sin dato de existencias."
    while time.monotonic()<limite:
        try:
            q=lectura(page.evaluate(CAPTURA,{'h':h}),sku,vid)
            if q==prev:return q
            prev=q
        except ValueError as err:prev=None;motivo=str(err)
        page.wait_for_timeout(350)
    raise ValueError(motivo)

def consultar(skus,status=lambda txt:None):
    from playwright.sync_api import sync_playwright, TimeoutError as BrowserTimeout
    with sync_playwright() as pw:
        if not Path(pw.chromium.executable_path).is_file():
            raise RuntimeError("Falta Chromium en esta computadora. En la misma terminal y entorno donde instalaste Streamlit, ejecuta: python -m playwright install chromium. Después vuelve a pulsar Consultar.")
        browser=pw.chromium.launch(headless=False)
        try:
            ctx=browser.new_context(locale="es-MX");account=ctx.new_page()
            status("Inicia sesión directamente en la ventana de Ledvance. La app esperará hasta 5 minutos.")
            cuenta_activa(account,300)
            idx=indice(ctx);page=ctx.new_page();filas=[];errores={}
            for i,s in enumerate(skus,1):
                if i%12==0:cuenta_activa(account,10)
                status(f"{i}/{len(skus)} · SKU {s}")
                try:q=leer_ficha(page,s,idx[s])
                except (ValueError,BrowserTimeout) as e:
                    q=None;errores[s]=str(e).splitlines()[0][:160]
                filas.append((s,q))
            cuenta_activa(account,10)
            return filas,errores
        finally:browser.close()
